var app = {
    initialize: function() {
        document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
    },
    onDeviceReady: function() {
        this.receivedEvent('deviceready');
    },
      receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');
        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');
        console.log('Received Event: ' + id);}};
        app.initialize();
        var app = angular.module('Myapp', []);
         app.controller('MyCtrl', function($scope, $http) {
          $scope.formData = {};
         $scope.showMe = true;
         $scope.hide = true;
        
         $scope.Login = function() {
         $scope.showMe = true;
         $scope.hide = true;
             };

		    $scope.Registro= function() {
		        $scope.showMe =false;
		        $scope.hide = false;
		    };


		  $scope.Logear=function(){
		  //$scope.formData = {};
         //console.log(formData.usernamelog.length); 

             
		  }  

});




